import LcnExec.GeneralEngine.Softmax
#print axioms LcnExec.GeneralEngine.softmax_at_spec
