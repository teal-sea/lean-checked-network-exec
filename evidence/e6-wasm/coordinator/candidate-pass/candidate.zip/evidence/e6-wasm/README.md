# E6 private browser integration

The page uses the exact E4 `rust/general_engine` crate and the E5 trained byte model. Both weights and the rebuilt Wasm are bound by [the build manifest](build-manifest.json). Unpack the local page ZIP into a private directory before replaying it.

## Browser replay

Run from the checkout or unpacked page with an existing Node and Chromium on Linux.

```sh
node scripts/e6_browser_replay.js
```

The harness starts a task-owned HTTP server on `127.0.0.1` and a fresh Chromium profile on at most two CPUs. It prints the evidence directory under `evidence/e6-wasm/browser-run-*/`. A successful run records SHA-256 of the actual Wasm and weight response bodies observed by the page, request logs, the native comparison, the real file-input events, and PNG screenshots. It stops the browser and server when done. For manual private viewing, run `node scripts/e6_browser_replay.js --serve 8765` and open `http://127.0.0.1:8765/web/index.html`. Stop the loopback server with Ctrl-C.

This worker returned `listen EPERM: operation not permitted 127.0.0.1`. A separate isolated Chromium probe exited 133 at Crashpad `setsockopt: Operation not permitted (1)`. Browser startup, actual HTTP response hash comparison, the browser sweep, and screenshots are pending coordinator replay. See [the loopback log](browser-harness.log) and [the Chromium probe](chromium-probe.log).

## Local results

| Check | Measured result |
| --- | --- |
| Exact Rust 1.99.1 offline locked Wasm build | Passed with overflow checks on |
| Wrapper parser tests | 4/4 passed |
| Native mod-113 | 12,769/12,769 exact in 31.789 s, frozen logits FNV-1a `6cb24f7670e8562e` |
| Single-threaded Node Wasm mod-113 | 12,769/12,769 exact in 121.101 s |
| Trained byte model, native versus Node Wasm | 5/5 prompt byte and greedy sequence matches, 256/256 signed logits for the first prompt, deterministic repeat |
| Native and Node Wasm rejection | Native parsed the corrupt file and rejected its bounds. Wasm returned load 0, predict −1 and logits pointer 0 |
| Upload recovery, real Wasm with a Node DOM fixture | Pre-fix failed and post-fix passed |

The first prompt, `A stitch in time`, generated the 16 bytes ` saves nine.\nThe` in both native Rust and Node Wasm. One recorded Wasm run took 5.38 s for those 16 steps. The verifier stores native and Wasm logits as signed decimal strings and compares them as `BigInt` values. See [the native reference](native-general.json) and [the Node Wasm receipt](RECEIPT.json).

The earlier provisional browser run exposed the [original upload failure](../e4-e6-integration/provisional-browser-replay-20261120.json). The checked-in pre-fix JavaScript and HTML are saved byte-for-byte, and [the failing replay](upload-regression-before.json) uses the rebuilt Wasm. The rejected upload overwrote the recovery buffer, with Generate enabled and Restore hidden. [The repaired replay](upload-regression-after.json) retains the approved file hash, exposes Restore, blocks generation, and generates the same bytes after restoration. The [fixture manifest](fixtures/manifest.json) records the one-byte mutation at offset 16.

## Rebuild from the integration worktree

```sh
sh web/build.sh
node scripts/e6_upload_regression.js before  # expected exit 1
node scripts/e6_upload_regression.js after
python3 -I scripts/e6_package.py
node scripts/e6_wasm_receipt.js
```

Regenerate the native reference on the repository checkout with the installed Rust 1.99.1 toolchain, using an ignored target directory.

```sh
cargo +1.99.1 run --manifest-path rust/general_engine_wasm/Cargo.toml \
  --release --offline --locked -j 2 --target-dir rust/general_engine_wasm/target/e6-native-replay \
  --example e6_native
```

Use `python3 -I scripts/e6_package.py` after regenerating the native reference to update the manifest. The manifest binds exact bytes, including the reference's measured timings. Packaging the same inputs produces the same ZIP.

## Proof scope

`GeneralEngineCorrect` covers the translated `predict_next` for every load-accepted weight set and all input sequences. The theorem concerns the Aeneas translation and the frozen integer specification. The Rust extraction association, Rust-to-Wasm compiler, Wasm wrapper, binary parser, generation loop, non-greedy sampler, browser and transport are outside that generic proof. The trained weights and the mod-113 checkpoint are identified by their hashes and tested separately.
