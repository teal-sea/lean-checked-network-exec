import LcnExec.GeneralEngine.Attention
#print axioms LcnExec.GeneralEngine.head_scores_at_spec
